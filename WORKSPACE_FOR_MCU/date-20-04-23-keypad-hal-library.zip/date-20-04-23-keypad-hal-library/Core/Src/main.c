#include"main.h"
#include<stdio.h>

int main()
{
	while(1)
	{
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,0);

		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_4)))
		{
			HAL_Delay(100);
			printf("1 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_5)))
		{
			HAL_Delay(100);
			printf("2 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_6)))
		{
			HAL_Delay(100);
			printf("3 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_7)))
		{
			HAL_Delay(100);
			printf("A is pressed");
		}

		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,0);

		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_4)))
		{
			HAL_Delay(100);
			printf("4 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_5)))
		{
			HAL_Delay(100);
			printf("5 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_6)))
		{
			HAL_Delay(100);
			printf("6 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_7)))
		{
			HAL_Delay(100);
			printf("B is pressed");
		}


		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,0);

		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_4)))
		{
			HAL_Delay(100);
			printf("7 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_5)))
		{
			HAL_Delay(100);
			printf("8 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_6)))
		{
			HAL_Delay(100);
			printf("9 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_7)))
		{
			HAL_Delay(100);
			printf("C is pressed");
		}


		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,0);

		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_4)))
		{
			HAL_Delay(100);
			printf("* is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_5)))
		{
			HAL_Delay(100);
			printf("0 is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_6)))
		{
			HAL_Delay(100);
			printf("# is pressed");
		}
		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_7)))
		{
			HAL_Delay(100);
			printf("D is pressed");
		}
	}
}
